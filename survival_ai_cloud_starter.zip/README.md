# Survival AI — Android cloud build starter

**Status:** working-source *candidate*, not a compiled or phone-tested APK. The
GitHub Actions workflow is provided but has not yet run because the connected
GitHub account has no repository. This is the foundation for the **full product**,
not a claim that the product is finished.

## What is implemented

- Native Android front end with five screens: Chat, Models, Library, Profile, Status.
- The official llama.cpp Android inference bindings are reused at a pinned upstream commit.
- Import GGUF files via Android's document picker into private app storage.
- Download GGUF files from a user-provided direct HTTPS URL; basic GGUF magic check,
  12 GB size limit, and storage checks. **Publisher SHA-256 verification is not yet
  implemented**: do not treat arbitrary URLs as trusted.
- Run chat locally against the chosen model with a practical-survival prompt.
- SQLite FTS4 offline full-text indexing and retrieval; TXT/Markdown imports only.
- A small orientation library is included. These notes are not vetted technical manuals.
- Profile fields (region, household, resources, optional care notes) encrypted using
  Android Keystore AES-256-GCM, with application backups disabled.
- Encrypted local recent chat history.
- Conservative hardware-tier suggestion derived from physical RAM.
- Status screen showing missing capabilities instead of pretending they are ready.

## What is deliberately NOT implemented yet

- Real regional downloads (maps, flora, fauna, emergency facilities, hazards).
- Curated, licence-cleared medical, survival and engineering reference packs.
- Reliable PDF extraction/RAG embeddings, media recognition and offline voice.
- Model integrity checking against publisher checksums, download resumption, and full
  lifecycle management for model switching.
- Android package signing for Play Store, iOS client, and independent test results.
- Benchmarked safety/engineering evaluations on target hardware.

## Build in GitHub Actions (no local computer)

1. Create an empty **private** GitHub repository called `survival-ai` using
   https://github.com/new while signed in to the connected GitHub account.
2. Add the project files and folders to that repository. The .github workflow
   runs when files are pushed to `main`, or manually through Actions.
3. In GitHub, open **Actions → Build Android survival AI APK → Run workflow**.
4. When successful, open the run's **Artifacts** and download
   `survival-ai-android-debug` to your Android phone. Unzip it, then install the
   debug APK. This is a test build, not a Play Store distribution.
5. Import a small, trusted GGUF and test in airplane mode.

The official Android source currently requires Android SDK 36, NDK 29.0.13113456
and CMake 3.31.6; GitHub Actions installs these automatically. Cloud build time,
free-tier eligibility, and available runner storage are subject to GitHub policy.

### Easy bootstrap from a phone

If a mobile browser cannot upload a folder tree, create the empty repo and use
ChatGPT **Work** with its cloud browser to upload the supplied archive's extracted
files to GitHub, or upload the files with a GitHub-compatible mobile client.
A `.zip` uploaded alone to GitHub **does not** activate its internal workflow.

## Development architecture

GitHub repo -> pinned `llama.cpp` checkout -> overlay our Android application ->
Gradle/CMake native build -> APK artifact -> physical-device testing.

The downloaded AI model and references run **on-device**, never on the cloud
build runner. Cloud services are only required while preparing/installing the app
or explicitly downloading reference/model updates. A successful CI build is **not**
proof that a 7–12B model can fit in a particular phone's available RAM.

## Initial acceptance checklist

- APK compiles in the cloud.
- Fresh app shows onboarding/profile and identifies physical RAM.
- GGUF can be imported, and small model inference works in airplane mode.
- Imported TXT/Markdown passages are searchable without connectivity.
- Profile survives restart, remains encrypted and is not included in backups.
- Failed model import or inference is reported without crashing.
- Multi-GB model downloads are not silently required at installation.

## Privacy and medical/engineering limitations

Sensitive profile and recent chat fields are stored locally with Android Keystore
AES-GCM. Documents and downloaded model files are in private app storage but **not
individually encrypted**. Do not import secrets into the library. Treat all AI
output as unverified until corroborated, particularly for medical treatment,
voltage/current, chemistry, plant identification, and load-bearing structures.

## Phone-only two-file cloud bootstrap (alternative)

1. Create your own private GitHub repository with a README (so a default `main` branch exists).
2. Upload **`survival_ai_cloud_starter.zip`** unchanged to the root of the repo.
3. Create `.github/workflows/bootstrap.yml` in GitHub's web editor, and paste the contents of the separate **`cloud-bootstrap.yml`** file supplied with this kit.
4. The GitHub Actions run will unpack the ZIP, build the Android native app and supply an APK artifact.

This method avoids having to upload directories from a mobile browser. The workflow is
executed on GitHub-hosted runners; AI inference itself will always be on your device.
