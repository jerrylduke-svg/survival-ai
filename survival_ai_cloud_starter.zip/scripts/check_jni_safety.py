#!/usr/bin/env python3
"""Prevent inference JNI calls from blocking ART's GC suspend handshake."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent.parent
runtime = root / 'overlay/lib/src/main/java/com/arm/aichat/internal/InferenceEngineImpl.kt'
source = runtime.read_text(encoding='utf-8')
methods = re.findall(r'((?:\s*@\w+\s*)*)private external fun (\w+)\(', source)
assert methods, 'No native inference boundary found'
unsafe = [name for annotations, name in methods if re.search(r'@(FastNative|CriticalNative)\b', annotations)]
assert not unsafe, (
    'Inference JNI must allow ART to suspend for GC; long-running native calls use unsafe fast transitions: '
    + ', '.join(unsafe)
)
print('PASS: all inference JNI methods use normal, GC-suspendable transitions')
