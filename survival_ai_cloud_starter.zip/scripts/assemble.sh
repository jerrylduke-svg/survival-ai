#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
UPSTREAM="${ROOT}/.upstream/llama.cpp"
# Pinned upstream revision inspected on 2026-10-10.
LLAMA_SHA="69f201a2051ea9b9e9b50c3cc56afd9e2ae64414"
if [ ! -d "$UPSTREAM/.git" ]; then
  mkdir -p "$(dirname "$UPSTREAM")"
  git clone --filter=blob:none https://github.com/ggml-org/llama.cpp.git "$UPSTREAM"
fi
git -C "$UPSTREAM" checkout --detach "$LLAMA_SHA"
DEST="$UPSTREAM/examples/llama.android"
cp -R "$ROOT/overlay/app/src/main/." "$DEST/app/src/main/"
# Keep app and namespace consistent with the vetted llama.cpp integration.
sed -i 's/applicationId = "com.example.llama.aichat"/applicationId = "app.survival.intelligence"/' "$DEST/app/build.gradle.kts"
# Fix token accounting bug in native runtime.
# The bug counts user_prompt_size twice because current_position already includes it.
# The fix uses current_position + n_predict only.
sed -i 's/stop_generation_position = current_position + user_prompt_size + n_predict;/stop_generation_position = current_position + n_predict;/' "$UPSTREAM/examples/llama.android/lib/src/main/cpp/ai_chat.cpp"
printf '\nSource assembled at %s\n' "$DEST"
