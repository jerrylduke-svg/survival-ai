#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ROOT="$PWD"
UPSTREAM="${ROOT}/.upstream/llama.cpp"
# Pinned upstream revision inspected on 2026-10-10.
LLAMA_SHA="69f201a2051ea9b9e9b50c3cc56afd9e2ae64414"
if [ ! -d "$UPSTREAM/.git" ]; then
  mkdir -p "$(dirname "$UPSTREAM")"
  git clone --filter=blob:none https://github.com/ggml-org/llama.cpp.git "$UPSTREAM"
fi
git -C "$UPSTREAM" checkout --detach "$LLAMA_SHA"
DEST="$UPSTREAM/examples/llama.android"
cp -R "$ROOT/overlay/app/src/main/." "$DEST/app/src/main/"
cp -R "$ROOT/overlay/lib/src/main/." "$DEST/lib/src/main/"
mkdir -p "$DEST/app/src/test"
cp -R "$ROOT/overlay/app/src/test/." "$DEST/app/src/test/"
# Keep app and namespace consistent with the vetted llama.cpp integration.
sed -i 's/applicationId = "com.example.llama.aichat"/applicationId = "app.survival.intelligence"/' "$DEST/app/build.gradle.kts"
# Fix token accounting bug in native runtime.
# The bug counts user_prompt_size twice because current_position already includes it.
# The fix removes user_prompt_size from the stop position calculation.
sed -i 's/ + user_prompt_size//' "$UPSTREAM/examples/llama.android/lib/src/main/cpp/ai_chat.cpp"
printf '\nSource assembled at %s\n' "$DEST"
