#!/usr/bin/env python3
"""Fast source/configuration sanity checks. Not a substitute for an Android build."""
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parent.parent
manifest = root / 'overlay/app/src/main/AndroidManifest.xml'
xml = ET.parse(manifest)
android = '{http://schemas.android.com/apk/res/android}'
assert xml.find('application').get(android + 'allowBackup') == 'false', 'Backup must be off'
assert any(x.get(android + 'name') == 'android.permission.INTERNET' for x in xml.findall('uses-permission'))
main = (root / 'overlay/app/src/main/java/com/example/llama/MainActivity.kt').read_text()
data = (root / 'overlay/app/src/main/java/com/example/llama/SurvivalData.kt').read_text()
assert 'AiChat.getInferenceEngine' in main and 'runtime.sendUserPrompt' in main
assert 'android.net.Uri' in main and 'https' in main
assert 'AES/GCM/NoPadding' in data
assert 'CREATE VIRTUAL TABLE' in data and 'fts4' in data
assert 'secure.saveHistory' in main and 'secure.readHistory' in main
assert 'not installed' in main.lower()
print('PASS: source structure, offline-search hooks, encrypted profile/chat and manifest checks')
