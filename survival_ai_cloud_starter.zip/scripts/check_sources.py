#!/usr/bin/env python3
"""Fast source/configuration sanity checks. Not a substitute for an Android build."""
from pathlib import Path
import xml.etree.ElementTree as ET
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
subprocess.run([sys.executable, str(root / 'scripts/check_jni_safety.py')], check=True)

manifest = root / 'overlay/app/src/main/AndroidManifest.xml'
xml = ET.parse(manifest)
android = '{http://schemas.android.com/apk/res/android}'
assert xml.find('application').get(android + 'allowBackup') == 'false', 'Backup must be off'
assert any(x.get(android + 'name') == 'android.permission.INTERNET' for x in xml.findall('uses-permission'))

main = (root / 'overlay/app/src/main/java/com/example/llama/MainActivity.kt').read_text(encoding='utf-8')
data = (root / 'overlay/app/src/main/java/com/example/llama/SurvivalData.kt').read_text(encoding='utf-8')
setup = (root / 'overlay/app/src/main/java/com/example/llama/ModelSetupManager.kt').read_text(encoding='utf-8')
assemble = (root / 'scripts/assemble.sh').read_text(encoding='utf-8')

# ── Original checks ──────────────────────────────────────────────────────────

assert 'AiChat.getInferenceEngine' in main and 'runtime.sendUserPrompt' in main
assert 'android.net.Uri' in main and 'https' in main
assert 'AES/GCM/NoPadding' in data
assert 'CREATE VIRTUAL TABLE' in data and 'fts4' in data
assert 'secure.saveHistory' in main and 'secure.readHistory' in main
assert 'not installed' in main.lower()

assert 'downloadModel' in setup and 'verifyChecksum' in setup
assert 'EXPECTED_SHA256' in setup and 'EXPECTED_SIZE' in setup
assert 'HTTP_PARTIAL' in setup and 'HTTP_RANGE_NOT_SATISFIABLE' in setup

assert 'initializeEngineAndLoadModel' in main
assert 'startModelSetup' in main
assert 'setupInProgress' in main
assert 'engine == null' in main
assert 'fromSetup' in main

assert 'engine.destroy' not in main, 'onDestroy must not destroy the engine singleton'
assert 'AiChat.getInferenceEngine(applicationContext)' in main

# ── Thinking separator ────────────────────────────────────────────────────────

separator = (root / 'overlay/app/src/main/java/com/example/llama/ThinkingSeparator.kt').read_text(encoding='utf-8')
assert 'ThinkingSeparator' in main, 'Thinking separator class must exist'
assert 'var isThinking = true' in separator, 'Thinking separator must track states'
assert '<think>' in separator and '</think>' in separator, 'Thinking separator must handle think tags'
assert 'findPartialAtEnd' in separator, 'Thinking separator must handle delimiters split across chunks'

# ── Window insets ─────────────────────────────────────────────────────────────

assert 'WindowInsetsCompat' in main, 'WindowInsetsCompat import required'
assert 'ViewCompat.setOnApplyWindowInsetsListener' in main, 'Window insets listener required'
assert 'Type.systemBars()' in main, 'System bar insets must be handled'
assert 'Type.ime()' in main, 'IME (keyboard) insets must be handled'

# ── Batched UI updates ────────────────────────────────────────────────────────

assert 'SystemClock.elapsedRealtime' in main, 'Batched updates need time tracking'
assert 'lastUiUpdate' in main, 'Batched updates need last-update tracking'
assert '70' in main, 'Batch interval ~70ms expected'
assert 'runOnUiThread' in main or 'withContext(Dispatchers.Main)' in main, 'UI updates on main thread'

# ── Color scheme ──────────────────────────────────────────────────────────────

assert '#1C1917' in main, 'Warm near-black background required'
assert '#292524' in main, 'Charcoal surface required'
assert '#A16207' in main, 'Muted brown accent required'
assert '#F5F0EB' in main, 'Warm off-white text required'
assert '#A8A29E' in main, 'Readable gray secondary text required'
assert '50, 180, 160' not in main, 'Old teal accent must be replaced'

# ── Bottom navigation ─────────────────────────────────────────────────────────

assert 'bottomNav' in main, 'Bottom navigation required'
assert 'updateBottomNav' in main, 'Bottom navigation update required'

# ── Markdown converter ────────────────────────────────────────────────────────

assert 'markdownToSpanned' in main, 'Markdown converter required'
assert 'SpannableStringBuilder' in main, 'Markdown converter must use SpannableStringBuilder'
assert 'TypefaceSpan' in main, 'Markdown inline code styling required'
assert 'StyleSpan' in main, 'Markdown bold/italic styling required'
assert 'RelativeSizeSpan' in main, 'Markdown header sizing required'
assert 'BackgroundColorSpan' in main, 'Markdown code block background required'

# ── Stop button ───────────────────────────────────────────────────────────────

assert 'stopGeneration' in main, 'Stop generation method required'
assert 'Stop' in main, 'Stop button label required'
assert 'isGenerating' in main, 'Generation state tracking required'

# ── Privacy ───────────────────────────────────────────────────────────────────

assert 'Log.d' not in main and 'Log.e' not in main and 'Log.i' not in main, 'No logging of prompts/responses'
assert 'Log.d' not in data and 'Log.e' not in data and 'Log.i' not in data, 'No logging in data layer'

# ── Loading states ────────────────────────────────────────────────────────────

assert 'isModelLoading' in main, 'Model loading state tracking required'
assert 'ModelSetupState.Status.DOWNLOADING' in main, 'Downloading state must be shown'
assert 'ModelSetupState.Status.VERIFYING' in main, 'Verifying state must be shown'
assert 'ModelSetupState.Status.LOADING' in main, 'Loading state must be shown'
assert 'ModelSetupState.Status.FAILED' in main, 'Failed state must be shown'
assert 'ModelSetupState.Status.READY' in main, 'Ready state must be shown'

# ── Token accounting bug fix ──────────────────────────────────────────────────

assert 'user_prompt_size' in assemble, 'Token accounting bug fix must be in assemble.sh'
# Check that the buggy line is not present outside of sed commands and comments
for line in assemble.split('\n'):
    if 'stop_generation_position' in line and 'user_prompt_size' in line and 'sed' not in line and not line.strip().startswith('#'):
        raise AssertionError('Buggy token accounting line must be replaced: ' + line.strip())

print('PASS: source structure, offline-search hooks, encrypted profile/chat, manifest,')
print('      model setup, engine lifecycle, thinking separator, window insets, batched updates,')
print('      color scheme, bottom navigation, markdown, stop button, privacy, loading states,')
print('      and token accounting bug fix checks')
