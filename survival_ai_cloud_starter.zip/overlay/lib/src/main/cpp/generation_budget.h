#pragma once
#include <algorithm>

// Independent of KV positions: sliding the context cannot extend the requested work.
class GenerationBudget {
    int limit_ = 0;
    int generated_ = 0;
public:
    void reset(int limit) { limit_ = std::max(0, limit); generated_ = 0; }
    bool reached() const { return generated_ >= limit_; }
    void record() { ++generated_; }
    int generated() const { return generated_; }
};

inline bool prompt_fits(int tokens, int context, int headroom) {
    return tokens >= 0 && tokens <= context - headroom;
}
