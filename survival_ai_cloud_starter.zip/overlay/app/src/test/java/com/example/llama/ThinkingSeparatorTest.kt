package com.example.llama

import org.junit.Assert.assertEquals
import org.junit.Test

class ThinkingSeparatorTest {
    @Test fun everyChunkBoundaryHidesReasoning() {
        for (input in listOf("private reasoning</think>Final answer", "<think>private reasoning</think>Final answer")) {
            for (split in 0..input.length) {
                val parser = ThinkingSeparator()
                assertEquals("Final answer", parser.process(input.take(split)) + parser.process(input.drop(split)) + parser.finish())
            }
        }
    }
    @Test fun characterChunksAndRepeatedThinking() {
        val parser = ThinkingSeparator()
        val output = "secret</think>One<think>hidden</think>Two".map { parser.process(it.toString()) }.joinToString("")
        assertEquals("OneTwo", output + parser.finish())
    }
    @Test fun unfinishedReasoningAndMarkersAreDiscarded() {
        for (input in listOf("private reasoning", "private</thin", "<think>private</think")) {
            val parser = ThinkingSeparator()
            assertEquals("", parser.process(input) + parser.finish())
        }
        val parser = ThinkingSeparator()
        assertEquals("Final", parser.process("secret</think>Final<thi") + parser.finish())
    }
    @Test fun cancelledParserCannotLeakIntoNextRequest() {
        val cancelled = ThinkingSeparator()
        cancelled.process("private</thi")
        assertEquals("", cancelled.finish())
        val next = ThinkingSeparator()
        assertEquals("Final", next.process("different private</think>Final"))
    }
}
