package com.example.llama

import org.junit.Assert.*
import org.junit.Test

class ChatHistoryTest {
    @Test fun questionAndPendingReplyAreInSnapshotBeforeTokens() {
        val history = ChatHistory()
        val index = history.begin("Question")
        assertEquals(1, index)
        assertEquals(ChatEntry("You", "Question"), history.entries[0])
        assertTrue(history.entries[index].pending)
    }
    @Test fun processRecoveryKeepsQuestionAndMarksPendingReplyHonestly() {
        val history = ChatHistory()
        history.restore(listOf(ChatEntry("You", "Question"), ChatEntry("AI", "Visible partial", true)))
        assertEquals("Question", history.entries[0].body)
        assertTrue(history.entries[1].body.startsWith("Visible partial"))
        assertTrue(history.entries[1].body.contains("Interrupted"))
        assertFalse(history.entries[1].pending)
    }
    @Test fun lateCancelledProducerCannotOverwriteInterruptedReply() {
        val history = ChatHistory()
        val index = history.begin("Question")
        history.update(index, "Visible")
        history.interrupt(index)
        val saved = history.entries[index]
        history.update(index, "Late callback")
        history.complete(index, "Late completion")
        assertEquals(saved, history.entries[index])
        assertEquals(3, history.begin("Next question"))
    }
    @Test fun restoredCompletedReplyIsUnchanged() {
        val entries = listOf(ChatEntry("You", "Question"), ChatEntry("AI", "Final"))
        val history = ChatHistory()
        history.restore(entries)
        assertEquals(entries, history.entries)
        history.restore(emptyList())
        assertEquals(entries, history.entries)
    }
    @Test fun cannotStartSecondReplyWhileFirstIsPending() {
        val history = ChatHistory()
        history.begin("First")
        try { history.begin("Second"); fail("Overlapping request accepted") }
        catch (_: IllegalStateException) { }
        assertEquals(2, history.entries.size)
    }
}
