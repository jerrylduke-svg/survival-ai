package com.example.llama

internal data class ChatEntry(val role: String, val body: String, val pending: Boolean = false)

internal class ChatHistory {
    private val lines = mutableListOf<ChatEntry>()
    val entries: List<ChatEntry> get() = lines.toList()
    var restored = false
        private set

    fun begin(question: String): Int {
        check(lines.none { it.pending }) { "A reply is already pending" }
        lines.add(ChatEntry("You", question))
        lines.add(ChatEntry("AI", "", true))
        return lines.lastIndex
    }

    fun update(index: Int, body: String) {
        if (isPending(index)) lines[index] = lines[index].copy(body = body)
    }

    fun complete(index: Int, body: String) {
        if (isPending(index)) lines[index] = lines[index].copy(body = body, pending = false)
    }

    fun interrupt(index: Int, reason: String = "Interrupted; please send again") {
        if (isPending(index)) {
            val line = lines[index]
            lines[index] = line.copy(body = line.body + "\n[$reason]", pending = false)
        }
    }

    fun isPending(index: Int): Boolean = lines.getOrNull(index)?.pending == true

    fun restore(entries: List<ChatEntry>) {
        if (restored) return
        lines.addAll(entries)
        lines.indices.filter { lines[it].pending }.forEach { interrupt(it) }
        restored = true
    }
}
