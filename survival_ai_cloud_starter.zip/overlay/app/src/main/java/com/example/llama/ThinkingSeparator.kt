package com.example.llama

/** Qwen templates prefill thinking. Fail closed until the closing marker arrives. */
internal class ThinkingSeparator {
    var isThinking = true
        private set
    private var buffer = ""

    fun process(token: String): String {
        buffer += token
        val output = StringBuilder()
        while (buffer.isNotEmpty()) {
            val marker = if (isThinking) "</think>" else "<think>"
            val index = buffer.indexOf(marker)
            if (index >= 0) {
                if (!isThinking) output.append(buffer.substring(0, index))
                buffer = buffer.substring(index + marker.length)
                isThinking = !isThinking
            } else {
                val partial = findPartialAtEnd(buffer, marker)
                if (!isThinking) output.append(buffer.dropLast(partial.length))
                buffer = partial
                break
            }
        }
        return output.toString()
    }

    fun finish(): String {
        // Never flush an incomplete marker or unfinished reasoning.
        buffer = ""
        return ""
    }

    private fun findPartialAtEnd(text: String, delimiter: String): String {
        for (length in minOf(text.length, delimiter.length - 1) downTo 1) {
            if (text.endsWith(delimiter.take(length))) return delimiter.take(length)
        }
        return ""
    }
}
