package com.example.llama

import android.app.ActivityManager
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Heuristic advice only; actual runtime model loading is the definitive compatibility test. */
object HardwareAdvisor {
    fun totalRamGb(context: Context): Double {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memoryInfo)
        return memoryInfo.totalMem / 1_000_000_000.0
    }

    fun recommendation(context: Context): String {
        val ram = totalRamGb(context)
        return when {
            ram < 6.0 -> "Essential: 1–2B parameters, 4-bit GGUF"
            ram < 10.0 -> "Balanced: 2–4B parameters, 4-bit GGUF"
            ram < 14.0 -> "Advanced: 4–8B parameters, 4-bit GGUF"
            else -> "Advanced: 8–12B parameters, 4-bit GGUF (benchmark first)"
        }
    }
}

data class SurvivalProfile(
    val region: String = "",
    val household: String = "",
    val resources: String = "",
    val careNotes: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("region", region)
        put("household", household)
        put("resources", resources)
        put("care", careNotes)
    }
    companion object {
        fun fromJson(json: JSONObject) = SurvivalProfile(
            json.optString("region"), json.optString("household"),
            json.optString("resources"), json.optString("care")
        )
    }
}

/** AES-GCM encryption using an Android Keystore key; backups of profile data are disabled. */
class ProfileStore(private val context: Context) {
    private val alias = "survival_ai_private_profile_v1"
    private val prefs = context.getSharedPreferences("survival_profile", Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").run {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build())
            generateKey()
        }
    }

    private fun saveEncrypted(field: String, value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encoded = cipher.iv + cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(field, Base64.encodeToString(encoded, Base64.NO_WRAP)).apply()
    }
    private fun readEncrypted(field: String): String? {
        val stored = prefs.getString(field, null) ?: return null
        return try {
            val bytes = Base64.decode(stored, Base64.NO_WRAP)
            require(bytes.size > 28)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
            String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), Charsets.UTF_8)
        } catch (_: Exception) { null }
    }
    fun save(profile: SurvivalProfile) = saveEncrypted("encrypted", profile.toJson().toString())
    fun read(): SurvivalProfile = try {
        readEncrypted("encrypted")?.let { SurvivalProfile.fromJson(JSONObject(it)) } ?: SurvivalProfile()
    } catch (_: Exception) { SurvivalProfile() }
    fun saveHistory(history: String) = saveEncrypted("encrypted_chat", history)
    fun readHistory(): String = readEncrypted("encrypted_chat") ?: "[]"

}

data class ReferenceHit(val title: String, val source: String, val excerpt: String)

/** A genuinely offline SQLite FTS index for imported UTF-8 documents. PDFs are not yet supported. */
class OfflineKnowledge(context: Context) : SQLiteOpenHelper(context, "offline_refs.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE VIRTUAL TABLE documents USING fts4(title, source, body)")
        val starter = listOf(
            Triple("Preparedness essentials", "Built-in orientation notes (not a certified manual)",
                "Store potable water, shelf-stable food, lighting, necessary medications, a battery-powered radio, and multiple charging methods. Prepare paper copies of important contacts. Test equipment before emergencies. Never assume offline maps or stored facility listings are current."),
            Triple("Medical escalation", "Built-in orientation notes (not medical treatment guidance)",
                "Severe difficulty breathing, uncontrollable bleeding, altered consciousness, and signs of sepsis require urgent professional medical attention. Do not substitute unverified wild plants for antibiotics. Exact dosages and identification require authoritative sources."),
            Triple("Electrical safety", "Built-in orientation notes (not an electrical repair manual)",
                "Isolate power before handling electrical equipment. Damaged lithium batteries can ignite. Automotive electrical systems can provide extremely high short-circuit currents. Verify polarity and voltage using suitable instruments. Avoid connecting makeshift generators to building wiring.")
        )
        for ((title, source, body) in starter) {
            db.execSQL("INSERT INTO documents(title,source,body) VALUES (?,?,?)", arrayOf(title,source,body))
        }
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun add(title: String, source: String, text: String) {
        writableDatabase.execSQL("INSERT INTO documents(title,source,body) VALUES (?,?,?)", arrayOf(title, source, text))
    }
    fun count(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM documents", null).use {
        it.moveToFirst(); it.getInt(0)
    }
    fun search(raw: String, limit: Int = 4): List<ReferenceHit> {
        val words = Regex("[\\p{L}\\p{N}]{3,}").findAll(raw).map { it.value }.take(8).toList()
        if (words.isEmpty()) return emptyList()
        val match = words.joinToString(" OR ") { "\"$it\"" }
        val output = mutableListOf<ReferenceHit>()
        readableDatabase.rawQuery("SELECT title, source, body FROM documents WHERE documents MATCH ? LIMIT ?",
            arrayOf(match, limit.toString())).use { cursor ->
            while (cursor.moveToNext()) {
                val full = cursor.getString(2)
                output.add(ReferenceHit(cursor.getString(0), cursor.getString(1), full.take(850)))
            }
        }
        return output
    }
}

fun modelStorage(context: Context): File = File(context.filesDir, "models").apply { mkdirs() }
