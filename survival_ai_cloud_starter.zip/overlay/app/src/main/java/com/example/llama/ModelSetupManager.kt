package com.example.llama

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class ModelSetupState(
    val status: Status = Status.NOT_INSTALLED,
    val progress: Int = 0,
    val bytesDownloaded: Long = 0,
    val totalBytes: Long = 0,
    val errorMessage: String? = null
) {
    enum class Status { NOT_INSTALLED, DOWNLOADING, VERIFYING, LOADING, READY, FAILED }
}

class ModelSetupManager(private val context: Context) {

    companion object {
        const val MODEL_FILENAME = "Qwen3.5-9B-Q4_K_M.gguf"
        const val MODEL_URL = "https://huggingface.co/unsloth/Qwen3.5-9B-GGUF/resolve/main/Qwen3.5-9B-Q4_K_M.gguf"
        const val EXPECTED_SHA256 = "03b74727a860a56338e042c4420bb3f04b2fec5734175f4cb9fa853daf52b7e8"
        const val EXPECTED_SIZE = 5_680_522_464L
        private const val PREFS_NAME = "model_setup"
        private const val KEY_STATUS = "status"
        private const val KEY_BYTES = "bytes_downloaded"
        private const val CHUNK_SIZE = 8 * 1024 * 1024
        private const val STORAGE_MARGIN = 500_000_000L
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    @Volatile
    private var downloadInProgress = false

    fun getModelFile(): File = File(modelStorage(context), MODEL_FILENAME)

    fun getPartialFile(): File = File(modelStorage(context), "$MODEL_FILENAME.part")

    fun isModelDownloaded(): Boolean {
        val file = getModelFile()
        return file.exists() && file.length() == EXPECTED_SIZE
    }

    suspend fun isModelVerified(): Boolean = withContext(Dispatchers.IO) {
        val file = getModelFile()
        if (!file.exists() || file.length() != EXPECTED_SIZE) return@withContext false
        verifyChecksum(file)
    }

    fun getCurrentState(): ModelSetupState {
        val status = ModelSetupState.Status.valueOf(prefs.getString(KEY_STATUS, ModelSetupState.Status.NOT_INSTALLED.name)!!)
        val bytes = prefs.getLong(KEY_BYTES, 0L)
        return ModelSetupState(status = status, bytesDownloaded = bytes, totalBytes = EXPECTED_SIZE)
    }

    private fun saveState(state: ModelSetupState) {
        prefs.edit()
            .putString(KEY_STATUS, state.status.name)
            .putLong(KEY_BYTES, state.bytesDownloaded)
            .apply()
    }

    fun clearProgress() {
        prefs.edit().remove(KEY_BYTES).apply()
    }

    suspend fun downloadModel(
        onProgress: (ModelSetupState) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        if (downloadInProgress) {
            return@withContext Result.failure(IOException("Download already in progress"))
        }
        downloadInProgress = true
        try {
            val partialFile = getPartialFile()
            val modelFile = getModelFile()

            if (modelFile.exists() && modelFile.length() == EXPECTED_SIZE && verifyChecksum(modelFile)) {
                val readyState = ModelSetupState(status = ModelSetupState.Status.READY, progress = 100)
                saveState(readyState)
                onProgress(readyState)
                return@withContext Result.success(modelFile)
            }

            val dir = modelStorage(context)
            val requiredSpace = EXPECTED_SIZE + STORAGE_MARGIN
            if (dir.usableSpace < requiredSpace) {
                throw IOException("Insufficient storage: need ${requiredSpace / 1_000_000} MB but only ${dir.usableSpace / 1_000_000} MB available")
            }

            var existingBytes = if (partialFile.exists()) partialFile.length() else 0L

            if (existingBytes > 0 && existingBytes >= EXPECTED_SIZE) {
                partialFile.delete()
                existingBytes = 0L
            }

            val state = ModelSetupState(
                status = ModelSetupState.Status.DOWNLOADING,
                bytesDownloaded = existingBytes,
                totalBytes = EXPECTED_SIZE
            )
            saveState(state)
            onProgress(state)

            val connection = URL(MODEL_URL).openConnection() as HttpURLConnection
            connection.connectTimeout = 30_000
            connection.readTimeout = 60_000
            connection.instanceFollowRedirects = true

            if (existingBytes > 0) {
                connection.setRequestProperty("Range", "bytes=$existingBytes-")
            }

            connection.connect()

            val responseCode = connection.responseCode

            if (responseCode == HttpURLConnection.HTTP_PARTIAL) {
                val contentRange = connection.getHeaderField("Content-Range")
                if (contentRange != null) {
                    val expectedStart = existingBytes
                    val rangeMatch = Regex("bytes (\\d+)-").find(contentRange)
                    if (rangeMatch != null) {
                        val actualStart = rangeMatch.groupValues[1].toLong()
                        if (actualStart != expectedStart) {
                            partialFile.delete()
                            existingBytes = 0L
                            saveState(state.copy(bytesDownloaded = 0))
                            connection.disconnect()

                            val retryConnection = URL(MODEL_URL).openConnection() as HttpURLConnection
                            retryConnection.connectTimeout = 30_000
                            retryConnection.readTimeout = 60_000
                            retryConnection.instanceFollowRedirects = true
                            retryConnection.connect()
                            if (retryConnection.responseCode != HttpURLConnection.HTTP_OK) {
                                retryConnection.disconnect()
                                throw IOException("Server returned HTTP ${retryConnection.responseCode} on retry")
                            }
                            return@withContext performDownload(retryConnection, partialFile, modelFile, 0L, onProgress)
                        }
                    }
                }
                return@withContext performDownload(connection, partialFile, modelFile, existingBytes, onProgress)
            }

            if (responseCode == HttpURLConnection.HTTP_OK) {
                if (partialFile.exists()) partialFile.delete()
                existingBytes = 0L
                saveState(state.copy(bytesDownloaded = 0))
                return@withContext performDownload(connection, partialFile, modelFile, 0L, onProgress)
            }

            if (responseCode == HttpURLConnection.HTTP_REQ_TOO_RANGE) {
                if (partialFile.exists()) partialFile.delete()
                existingBytes = 0L
                saveState(state.copy(bytesDownloaded = 0))
                connection.disconnect()

                val retryConnection = URL(MODEL_URL).openConnection() as HttpURLConnection
                retryConnection.connectTimeout = 30_000
                retryConnection.readTimeout = 60_000
                retryConnection.instanceFollowRedirects = true
                retryConnection.connect()
                if (retryConnection.responseCode != HttpURLConnection.HTTP_OK) {
                    retryConnection.disconnect()
                    throw IOException("Server returned HTTP ${retryConnection.responseCode} after 416 retry")
                }
                return@withContext performDownload(retryConnection, partialFile, modelFile, 0L, onProgress)
            }

            connection.disconnect()
            throw IOException("Server returned HTTP $responseCode")
        } finally {
            downloadInProgress = false
        }
    }

    private suspend fun performDownload(
        connection: HttpURLConnection,
        partialFile: File,
        modelFile: File,
        existingBytes: Long,
        onProgress: (ModelSetupState) -> Unit
    ): Result<File> {
        try {
            val append = existingBytes > 0
            val state = ModelSetupState(
                status = ModelSetupState.Status.DOWNLOADING,
                bytesDownloaded = existingBytes,
                totalBytes = EXPECTED_SIZE
            )

            val inputStream = connection.inputStream
            val outputStream = FileOutputStream(partialFile, append)
            val buffer = ByteArray(CHUNK_SIZE)
            var totalBytes = existingBytes
            var lastReportedProgress = -1

            outputStream.use { out ->
                inputStream.use { input ->
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        out.write(buffer, 0, read)
                        totalBytes += read

                        val progress = ((totalBytes * 100) / EXPECTED_SIZE).toInt()
                        if (progress != lastReportedProgress) {
                            lastReportedProgress = progress
                            val progressState = state.copy(
                                progress = progress.coerceIn(0, 100),
                                bytesDownloaded = totalBytes
                            )
                            saveState(progressState)
                            onProgress(progressState)
                        }
                    }
                }
            }

            connection.disconnect()

            if (totalBytes != EXPECTED_SIZE) {
                throw IOException("Download incomplete: got $totalBytes bytes, expected $EXPECTED_SIZE")
            }

            val verifyingState = state.copy(status = ModelSetupState.Status.VERIFYING, progress = 100)
            saveState(verifyingState)
            onProgress(verifyingState)

            if (!verifyChecksum(partialFile)) {
                partialFile.delete()
                clearProgress()
                throw IOException("SHA-256 verification failed - file may be corrupt")
            }

            val loadingState = verifyingState.copy(status = ModelSetupState.Status.LOADING)
            saveState(loadingState)
            onProgress(loadingState)

            if (modelFile.exists()) modelFile.delete()
            if (!partialFile.renameTo(modelFile)) {
                throw IOException("Could not activate model file")
            }

            clearProgress()
            val readyState = ModelSetupState(status = ModelSetupState.Status.READY, progress = 100)
            saveState(readyState)
            onProgress(readyState)

            Result.success(modelFile)
        } catch (e: Exception) {
            val failedState = ModelSetupState(
                status = ModelSetupState.Status.FAILED,
                errorMessage = e.message ?: "Unknown error"
            )
            saveState(failedState)
            onProgress(failedState)
            Result.failure(e)
        }
    }

    private fun verifyChecksum(file: File): Boolean {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buffer = ByteArray(8 * 1024 * 1024)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        val hash = digest.digest().joinToString("") { "%02x".format(it) }
        return hash == EXPECTED_SHA256
    }

    fun resetSetup() {
        getPartialFile().delete()
        prefs.edit().clear().apply()
    }
}
