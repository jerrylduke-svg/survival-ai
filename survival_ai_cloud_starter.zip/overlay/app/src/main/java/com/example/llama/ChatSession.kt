package com.example.llama

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

internal data class ChatRunState(val generating: Boolean = false, val thinking: Boolean = false, val stopping: Boolean = false)

/** Process-owned history and write ordering survive activity recreation. Access history on Main. */
internal object ChatSession {
    val history = ChatHistory()
    val state = MutableStateFlow(ChatRunState())
    val changed = MutableStateFlow<Pair<Int, String>?>(null)
    var generation: Job? = null
    @OptIn(ExperimentalCoroutinesApi::class)
    val storageScope = CoroutineScope(SupervisorJob() + Dispatchers.IO.limitedParallelism(1))
    private var revision = 0L
    private var savedRevision = 0L

    fun notifyReply(index: Int) {
        history.entries.getOrNull(index)?.let { changed.value = index to it.body }
    }

    fun persist(store: ProfileStore): Deferred<Result<Unit>> {
        val snapshot = history.entries.takeLast(30)
        val version = ++revision
        return storageScope.async {
            runCatching {
                if (version > savedRevision) {
                    val entries = JSONArray()
                    snapshot.forEach { line ->
                        entries.put(JSONObject().put("role", line.role).put("body", line.body.take(6000)).put("pending", line.pending))
                    }
                    store.saveHistory(entries.toString())
                    savedRevision = version
                }
            }
        }
    }
}
