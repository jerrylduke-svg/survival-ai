package com.example.llama

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.URL
import java.net.HttpURLConnection
import java.security.MessageDigest
import java.util.Locale

/** Offline survival assistant: native GGUF inference, thinking/content separation, modern UI. */
class MainActivity : AppCompatActivity() {

    // Brown / black / gray color scheme
    private val background = Color.parseColor("#1C1917")
    private val surface = Color.parseColor("#292524")
    private val surfaceVariant = Color.parseColor("#44403C")
    private val accent = Color.parseColor("#A16207")
    private val accentDark = Color.parseColor("#78350F")
    private val textPrimary = Color.parseColor("#F5F0EB")
    private val textSecondary = Color.parseColor("#A8A29E")
    private val errorColor = Color.parseColor("#DC2626")

    private lateinit var mainFrame: FrameLayout
    private lateinit var indicator: TextView
    private lateinit var knowledge: OfflineKnowledge
    private lateinit var secure: ProfileStore
    private var profile = SurvivalProfile()
    private var engine: InferenceEngine? = null
    private var model: File? = null
    private var busy = false
    private var isGenerating = false
    private var isThinking = false
    private var stopping = false
    private var isModelLoading = false
    private var generation: Job? = null
    private var currentPage = "Chat"
    private val transcript = mutableListOf<Pair<String, String>>()
    private var conversationLayout: LinearLayout? = null
    private var conversationScroll: ScrollView? = null
    private var composerInput: EditText? = null
    private var composerSendButton: Button? = null
    private var bottomNav: LinearLayout? = null
    private lateinit var setupManager: ModelSetupManager
    private var setupShowing = false
    private var setupInProgress = false

    // Batching
    private val uiHandler = Handler(Looper.getMainLooper())
    private var lastUiUpdate = 0L
    private var streamText = ""

    private val ggufPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importModel(uri)
    }
    private val textPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importReference(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        knowledge = OfflineKnowledge(this)
        secure = ProfileStore(this)
        setupManager = ModelSetupManager(this)
        profile = secure.read()
        restoreTranscript()
        window.statusBarColor = background
        window.navigationBarColor = background
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(this@MainActivity.background)
        }
        // Compact header
        root.addView(text("SURVIVAL AI", 20, textPrimary, true).apply {
            setPadding(px(16), px(12), px(16), px(2))
        })
        indicator = text("Offline • No model loaded", 12, textSecondary).apply {
            setPadding(px(16), 0, px(16), px(8))
        }
        root.addView(indicator)

        mainFrame = FrameLayout(this)
        root.addView(mainFrame, LinearLayout.LayoutParams(-1, 0, 1f))

        // Bottom navigation
        bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(surface)
        }
        for (page in listOf("Chat", "Models", "Library", "Profile", "Status")) {
            val b = Button(this).apply {
                text = page
                textSize = 12f
                isAllCaps = false
                setTextColor(textSecondary)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { showPage(page) }
            }
            bottomNav!!.addView(b, LinearLayout.LayoutParams(0, px(48), 1f))
        }
        root.addView(bottomNav!!)

        // One inset owner avoids counting the navigation bar and IME twice.
        ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            view.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }

        setContentView(root)

        if (setupManager.isModelDownloaded()) {
            showPage(if (profile.region.isBlank() && profile.household.isBlank()) "Profile" else "Chat")
            initializeEngineAndLoadModel()
        } else {
            showSetupScreen()
        }
    }

    private fun initializeEngineAndLoadModel() {
        lifecycleScope.launch(Dispatchers.Default) {
            try {
                val loaded = AiChat.getInferenceEngine(applicationContext)
                withContext(Dispatchers.Main) {
                    engine = loaded
                    updateIndicator()
                    if (setupManager.isModelDownloaded() && model == null) {
                        loadModel(setupManager.getModelFile())
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    toast("Inference engine error: ${e.message}")
                    updateIndicator()
                }
            }
        }
    }

    private fun showSetupScreen() {
        setupShowing = true
        val column = pageColumn()
        val scroll = ScrollView(this).apply { isFillViewport = true }
        scroll.addView(column)
        mainFrame.removeAllViews()
        mainFrame.addView(scroll)

        column.addView(section("Welcome to Survival AI"))
        addNote(column, "This app works fully offline. To get started, we need to download the AI model that powers your assistant.")
        addNote(column, "Model: Qwen3.5-9B (Q4_K_M quantization)")
        addNote(column, "Size: ~5.7 GB")
        addNote(column, "License: Apache 2.0")
        addNote(column, "This is a one-time download. After setup, the app works completely offline - no internet, no subscriptions, no accounts.")
        addNote(column, "Please connect to Wi-Fi before downloading. The download can be resumed if interrupted.")

        val freeSpace = modelStorage(this).usableSpace
        val requiredSpace = ModelSetupManager.EXPECTED_SIZE + 500_000_000L
        if (freeSpace < requiredSpace) {
            addNote(column, "WARNING: Low storage. You need ${(requiredSpace / 1_000_000_000.0).format(1)} GB free but only have ${(freeSpace / 1_000_000_000.0).format(1)} GB available.")
        }

        val startButton = action("Download and Setup Model") {
            startModelSetup()
        }
        startButton.tag = "setup_button"
        column.addView(startButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(16) })

        val statusText = text("", 14, textSecondary)
        statusText.tag = "setup_status"
        column.addView(statusText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(16) })

        val progressText = text("", 14, accent)
        progressText.tag = "setup_progress"
        column.addView(progressText, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(8) })

        val retryButton = action("Retry Setup") {
            setupInProgress = false
            startModelSetup()
        }
        retryButton.tag = "setup_retry"
        retryButton.visibility = View.GONE
        column.addView(retryButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = px(8) })
    }

    private fun Double.format(digits: Int) = "%.${digits}f".format(this)

    private fun startModelSetup() {
        if (setupInProgress) return
        setupInProgress = true

        val statusText = mainFrame.findViewWithTag<TextView>("setup_status")
        val progressText = mainFrame.findViewWithTag<TextView>("setup_progress")
        val startButton = mainFrame.findViewWithTag<android.widget.Button>("setup_button")
        val retryButton = mainFrame.findViewWithTag<android.widget.Button>("setup_retry")

        startButton?.isEnabled = false

        lifecycleScope.launch {
            try {
                val result = setupManager.downloadModel { state ->
                    runOnUiThread {
                        when (state.status) {
                            ModelSetupState.Status.DOWNLOADING -> {
                                statusText?.text = "Downloading model... ${state.bytesDownloaded / 1_000_000} MB / ${state.totalBytes / 1_000_000} MB"
                                progressText?.text = "${state.progress}%"
                            }
                            ModelSetupState.Status.VERIFYING -> {
                                statusText?.text = "Verifying download integrity..."
                                progressText?.text = "100%"
                            }
                            ModelSetupState.Status.LOADING -> {
                                statusText?.text = "Preparing to load model..."
                                progressText?.text = ""
                            }
                            ModelSetupState.Status.READY -> {
                                statusText?.text = "Model verified. Loading..."
                                progressText?.text = ""
                            }
                            ModelSetupState.Status.FAILED -> {
                                statusText?.text = "Setup failed: ${state.errorMessage}"
                                progressText?.text = ""
                            }
                            else -> {}
                        }
                    }
                }

                result.onSuccess { modelFile ->
                    runOnUiThread {
                        statusText?.text = "Initializing AI engine..."
                    }

                    if (engine == null) {
                        try {
                            val loaded = withContext(Dispatchers.Default) {
                                AiChat.getInferenceEngine(applicationContext)
                            }
                            engine = loaded
                        } catch (e: Exception) {
                            runOnUiThread {
                                statusText?.text = "Engine initialization failed: ${e.message}. Please retry."
                                startButton?.isEnabled = true
                                retryButton?.visibility = View.VISIBLE
                                setupInProgress = false
                            }
                            return@launch
                        }
                    }

                    runOnUiThread {
                        statusText?.text = "Loading model..."
                        loadModel(modelFile, fromSetup = true)
                        setupShowing = false
                        setupInProgress = false
                        showPage("Chat")
                    }
                }.onFailure { error ->
                    runOnUiThread {
                        statusText?.text = "Setup failed: ${error.message}. Tap retry to try again."
                        startButton?.isEnabled = true
                        retryButton?.visibility = View.VISIBLE
                        setupInProgress = false
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText?.text = "Setup error: ${e.message}. Tap retry to try again."
                    startButton?.isEnabled = true
                    retryButton?.visibility = View.VISIBLE
                    setupInProgress = false
                }
            }
        }
    }

    private fun text(value: String, size: Int = 15, color: Int = textPrimary, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            setPadding(px(12), px(10), px(12), px(10))
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun px(n: Int): Int = (n * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun section(s: String): TextView = text(s, 19, textPrimary, true)
    private fun action(label: String, click: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { click() }
    }
    private fun input(hint: String, initial: String = "", lines: Int = 1): EditText = EditText(this).apply {
        setText(initial)
        this.hint = hint
        setHintTextColor(textSecondary)
        setTextColor(textPrimary)
        textSize = 15f
        minLines = lines
        maxLines = if (lines == 1) 1 else 6
        setBackgroundColor(surface)
        setPadding(px(12), px(10), px(12), px(10))
    }
    private fun pageColumn(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(px(14), px(8), px(14), px(24))
    }
    private fun addNote(parent: LinearLayout, label: String) {
        parent.addView(text(label, 14, textSecondary), LinearLayout.LayoutParams(-1, -2))
    }
    private fun scrollPage(build: (LinearLayout) -> Unit) {
        val column = pageColumn()
        build(column)
        val scroll = ScrollView(this)
        scroll.addView(column)
        mainFrame.removeAllViews()
        mainFrame.addView(scroll)
    }
    private fun showPage(page: String) {
        currentPage = page
        conversationLayout = null
        conversationScroll = null
        composerInput = null
        composerSendButton = null
        when (page) {
            "Chat" -> showChat()
            "Models" -> showModels()
            "Library" -> showLibrary()
            "Profile" -> showProfile()
            else -> showStatus()
        }
        updateBottomNav()
    }

    private fun showChat() {
        val vertical = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(this@MainActivity.background)
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(this@MainActivity.background)
        }
        conversationScroll = scroll
        val log = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), px(8), px(12), px(8))
        }
        conversationLayout = log
        if (transcript.isEmpty()) addNote(log, "Ask about preparedness, repairs, water, navigation or engineering. Download a model first. Responses are not verified medical or electrical instructions.")
        for ((role, body) in transcript) addBubble(log, role, body)
        scroll.addView(log)
        vertical.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        // Composer
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(px(8), px(8), px(8), px(8))
            setBackgroundColor(surface)
        }
        composerInput = input("Ask your offline assistant")
        composerSendButton = action("Send") {
            val question = composerInput?.text?.toString() ?: ""
            send(question)
            composerInput?.setText("")
        }
        composer.addView(composerInput, LinearLayout.LayoutParams(0, -2, 1f))
        composer.addView(composerSendButton, LinearLayout.LayoutParams(px(100), px(56)))
        vertical.addView(composer)
        mainFrame.removeAllViews()
        mainFrame.addView(vertical)
        updateComposerState()
    }
    private fun addBubble(parent: LinearLayout, role: String, body: String): TextView {
        val heading = text(if (role == "You") "YOU" else "SURVIVAL AI", 11, accent, true)
        parent.addView(heading)
        val bubble = text(body, 15, textPrimary).apply {
            if (role != "You") text = markdownToSpanned(body)
            setBackgroundColor(surface)
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(12) }
        parent.addView(bubble, lp)
        return bubble
    }
    private fun send(question: String) {
        if (question.isBlank() || isGenerating || isModelLoading) return
        val runtime = engine
        if (runtime == null || model == null || runtime.state.value !is InferenceEngine.State.ModelReady) {
            toast("Wait for the model to finish loading."); return
        }
        composerInput?.setText("")
        transcript.add("You" to question)
        transcript.add("AI" to "")
        val answerIndex = transcript.lastIndex
        val parent = if (currentPage == "Chat") conversationLayout else null
        parent?.let { addBubble(it, "You", question) }
        parent?.let { addBubble(it, "AI", "Thinking...") }?.tag = "answer_$answerIndex"
        isGenerating = true
        isThinking = true
        stopping = false
        updateIndicator()
        updateComposerState()
        lastUiUpdate = 0L
        generation = lifecycleScope.launch(Dispatchers.Default) {
            val separator = ThinkingSeparator()
            val result = StringBuilder()
            suspend fun publish(value: String) = withContext(Dispatchers.Main) {
                transcript[answerIndex] = "AI" to value
                isThinking = separator.isThinking
                updateIndicator()
                conversationLayout?.findViewWithTag<TextView>("answer_$answerIndex")?.text = markdownToSpanned(value)
                scrollToBottom()
            }
            try {
                val hits = withContext(Dispatchers.IO) { knowledge.search(question, 3) }
                runtime.sendUserPrompt(composePrompt(question, hits)).collect { token ->
                    result.append(separator.process(token))
                    val now = SystemClock.elapsedRealtime()
                    if (!separator.isThinking && now - lastUiUpdate >= 70) {
                        lastUiUpdate = now
                        publish(result.toString())
                    }
                }
                separator.finish()
                if (result.isEmpty()) result.append("No final answer was generated. Please try again.")
                else if (hits.isNotEmpty()) result.append("\n\nLocal references consulted: " + hits.joinToString { it.title })
            } catch (e: CancellationException) {
                separator.finish()
                result.append("\n[Stopped]")
            } catch (_: Exception) {
                separator.finish()
                result.append("\n[Generation failed. Please reload the model and retry.]")
            } finally {
                withContext(NonCancellable + Dispatchers.Main) {
                    publish(result.toString())
                    persistTranscript()
                    isGenerating = false
                    isThinking = false
                    stopping = false
                    generation = null
                    updateIndicator()
                    updateComposerState()
                }
            }
        }
    }
    private fun stopGeneration() {
        if (!isGenerating || stopping) return
        stopping = true
        generation?.cancel()
        updateIndicator()
        updateComposerState()
    }
    private fun scrollToBottom() {
        conversationScroll?.post {
            conversationScroll?.fullScroll(View.FOCUS_DOWN)
        }
    }
    private fun updateComposerState() {
        val button = composerSendButton ?: return
        if (isGenerating) {
            button.text = if (stopping) "Stopping" else "Stop"
            button.isEnabled = !stopping
            button.setOnClickListener { stopGeneration() }
        } else {
            button.text = "Send"
            button.isEnabled = !isModelLoading && model != null && engine?.state?.value is InferenceEngine.State.ModelReady
            button.setOnClickListener {
                val question = composerInput?.text?.toString() ?: ""
                send(question)

            }
        }
    }
    private fun composePrompt(question: String, hits: List<ReferenceHit>): String = buildString {
        append("You are an OFFLINE emergency preparedness and practical engineering assistant. ")
        append("Provide useful, factual steps for legitimate tasks, identify real hazards without reflexive refusals, and never invent technical values, dosages or references. ")
        append("For immediate medical emergencies recommend qualified help whenever possible. Reference passages may be incomplete or outdated. ")
        append("Distinguish documented claims from deductions and unknowns.\n")
        if (profile.region.isNotBlank()) append("Approximate user region: ${profile.region.take(100)}\n")
        if (profile.resources.isNotBlank()) append("Available resources: ${profile.resources.take(350)}\n")
        if (profile.household.isNotBlank()) append("Household context: ${profile.household.take(140)}\n")
        if (profile.careNotes.isNotBlank()) append("Relevant private care considerations: ${profile.careNotes.take(240)}\n")
        hits.forEachIndexed { index, hit ->
            append("[LOCAL SOURCE ${index + 1}: ${hit.title}, ${hit.source}]\n${hit.excerpt}\n")
        }
        append("User question: $question")
    }

    private fun showModels() = scrollPage { content ->
        content.addView(section("AI Model"))
        addNote(content, "Detected device RAM: %.1f GB. %s.".format(Locale.US, HardwareAdvisor.totalRamGb(this), HardwareAdvisor.recommendation(this)))
        val defaultModel = setupManager.getModelFile()
        if (defaultModel.exists()) {
            val loaded = if (model?.absolutePath == defaultModel.absolutePath) " [LOADED]" else ""
            content.addView(text("Default: ${defaultModel.name} (${defaultModel.length() / 1_000_000} MB)$loaded", 15, accent, true))
            if (model?.absolutePath != defaultModel.absolutePath) {
                content.addView(action("Load default model") { loadModel(defaultModel) })
            }
        } else {
            addNote(content, "Default model not installed. The app will prompt setup on next launch.")
        }
        val files = modelStorage(this).listFiles()?.filter { it.extension.lowercase() == "gguf" && it.name != ModelSetupManager.MODEL_FILENAME } ?: emptyList()
        if (files.isNotEmpty()) {
            addNote(content, "Additional models:")
            for (file in files) {
                content.addView(action("Load ${file.name} (${file.length() / 1_000_000} MB)") { loadModel(file) })
            }
        }
        addNote(content, "Advanced: import your own GGUF file (max 12 GB).")
        content.addView(action("Import a GGUF model from this phone") { ggufPicker.launch(arrayOf("*/*")) })
    }
    private fun importModel(uri: Uri) {
        if (busy) { toast("Finish the current task first."); return }
        val filename = documentName(uri).takeIf { it.endsWith(".gguf", true) } ?: run { toast("Choose a .gguf model file."); return }
        busy = true; updateIndicator()
        lifecycleScope.launch(Dispatchers.IO) {
            var tmp: File? = null
            try {
                val folder = modelStorage(this@MainActivity)
                tmp = File(folder, "incoming.part")
                contentResolver.openInputStream(uri).use { source ->
                    requireNotNull(source) { "Cannot open this document." }
                    FileOutputStream(tmp).use { dest -> source.copyTo(dest, 1024 * 1024) }
                }
                checkGguf(tmp)
                val dest = uniqueFile(folder, filename)
                require(tmp.renameTo(dest)) { "Could not move imported model." }
                withContext(Dispatchers.Main) { toast("Model imported; tap it to load."); showModels() }
            } catch (e: Exception) {
                tmp?.delete()
                withContext(Dispatchers.Main) { toast("Import failed: ${e.message}") }
            } finally { withContext(Dispatchers.Main) { busy = false; updateIndicator() } }
        }
    }
    private fun loadModel(file: File, fromSetup: Boolean = false) {
        if (isGenerating || isModelLoading) return
        if (!fromSetup && model != null && model?.absolutePath != file.absolutePath) {
            AlertDialog.Builder(this).setMessage("To safely release memory before switching models, restart the app, then select the new model.").setPositiveButton("OK", null).show()
            return
        }
        if (model?.absolutePath == file.absolutePath) { toast("Already loaded."); return }
        if (engine == null) {
            toast("AI engine is not ready yet. Please wait or retry.")
            return
        }
        isModelLoading = true; updateIndicator(); updateComposerState()
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                checkGguf(file)
                val runtime = engine ?: throw IllegalStateException("AI engine is not ready. Please retry.")
                withTimeout(60_000) { runtime.state.first { it is InferenceEngine.State.Initialized || it is InferenceEngine.State.Error } }
                runtime.loadModel(file.absolutePath)
                withContext(Dispatchers.Main) { model = file; toast("Model loaded — airplane mode is supported."); updateIndicator(); if (!fromSetup) showPage("Chat") }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { toast("Model could not load: ${e.message}"); updateIndicator() }
            } finally { withContext(Dispatchers.Main) { isModelLoading = false; updateIndicator(); updateComposerState() } }
        }
    }

    private fun modelDownloadDialog() {
        val url = input("Paste a direct HTTPS .gguf download URL", lines = 2)
        AlertDialog.Builder(this).setTitle("Download model")
            .setView(url)
            .setMessage("Downloads can exceed 10 GB. Verify the publisher and make sure sufficient storage is available. Models are stored on this device.")
            .setPositiveButton("Download") { _, _ -> downloadModel(url.text.toString().trim()) }
            .setNegativeButton("Cancel", null).show()
    }
    private fun downloadModel(link: String) {
        val uri = Uri.parse(link)
        if (uri.scheme != "https" || !uri.path.orEmpty().endsWith(".gguf", true)) {
            toast("Use a direct HTTPS URL ending in .gguf."); return
        }
        if (busy) return
        busy = true; updateIndicator()
        lifecycleScope.launch(Dispatchers.IO) {
            val dir = modelStorage(this@MainActivity)
            val temp = File(dir, "incoming.part")
            var connection: HttpURLConnection? = null
            try {
                connection = URL(link).openConnection() as HttpURLConnection
                connection.connectTimeout = 20_000
                connection.readTimeout = 60_000
                connection.instanceFollowRedirects = true
                connection.connect()
                require(connection.url.protocol == "https") { "Insecure download redirect refused." }
                require(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
                val length = connection.contentLengthLong
                require(length <= 12_000_000_000L) { "File exceeds the 12 GB download limit." }
                if (length > 0) require(dir.usableSpace > length + 500_000_000L) { "Insufficient free space." }
                connection.inputStream.use { input ->
                    FileOutputStream(temp).use { out ->
                        val buffer = ByteArray(1024 * 1024)
                        var written = 0L
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            written += count
                            require(written <= 12_000_000_000L) { "File exceeds the 12 GB limit." }
                            out.write(buffer, 0, count)
                        }
                    }
                }
                checkGguf(temp)
                val name = uri.lastPathSegment?.replace(Regex("[^A-Za-z0-9._-]"), "_") ?: "download.gguf"
                val dest = uniqueFile(dir, name)
                require(temp.renameTo(dest)) { "Unable to save model." }
                withContext(Dispatchers.Main) { toast("Downloaded ${dest.name}. Load it from Models."); showModels() }
            } catch (e: Exception) {
                temp.delete()
                withContext(Dispatchers.Main) { toast("Download failed: ${e.message}") }
            } finally {
                connection?.disconnect()
                withContext(Dispatchers.Main) { busy = false; updateIndicator() }
            }
        }
    }
    private fun checkGguf(file: File) {
        require(file.length() > 1024) { "Incomplete model file." }
        FileInputStream(file).use {
            val magic = ByteArray(4)
            require(it.read(magic) == 4 && String(magic, Charsets.US_ASCII) == "GGUF") { "Invalid GGUF header." }
        }
    }
    private fun uniqueFile(dir: File, raw: String): File {
        val clean = raw.replace(Regex("[^A-Za-z0-9._-]"), "_").take(150)
        var result = File(dir, clean)
        var index = 1
        while (result.exists()) { result = File(dir, "${index++}_$clean") }
        return result
    }
    private fun documentName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun showLibrary() = scrollPage { content ->
        content.addView(section("Offline survival library"))
        addNote(content, "${knowledge.count()} indexed documents. Search is on-device, including in airplane mode. Starter notes are orientation only, not authoritative technical or medical manuals.")
        content.addView(action("Import TXT or Markdown reference") { textPicker.launch(arrayOf("text/plain", "text/markdown", "*/*")) })
        addNote(content, "For now import UTF-8 .txt or .md files (maximum 8 MB each). PDF ingestion, curated regional packs and map packages are planned but not implemented in this build.")
        val field = input("Search saved references")
        content.addView(field)
        val results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(action("Search offline") {
            results.removeAllViews()
            val matches = try { knowledge.search(field.text.toString(), 12) } catch (e: Exception) { emptyList() }
            if (matches.isEmpty()) addNote(results, "No indexed passage matched this search.")
            for (hit in matches) {
                results.addView(text(hit.title, 16, accent, true))
                addNote(results, "${hit.source}\n${hit.excerpt}")
            }
        })
        content.addView(results)
    }
    private fun importReference(uri: Uri) {
        val name = documentName(uri)
        if (!(name.endsWith(".txt", true) || name.endsWith(".md", true))) {
            toast("Only UTF-8 .txt and .md files are supported in this build."); return
        }
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val text = contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input)
                    val out = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(32_768)
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        require(out.size() + read <= 8_000_000) { "Document exceeds 8 MB." }
                        out.write(buffer, 0, read)
                    }
                    out.toString("UTF-8")
                }
                require(text.isNotBlank()) { "Document is empty." }
                knowledge.add(name, "User-imported file: $name", text)
                withContext(Dispatchers.Main) { toast("Indexed $name for offline search."); showLibrary() }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { toast("Document import failed: ${e.message}") }
            }
        }
    }
    private fun showProfile() = scrollPage { content ->
        content.addView(section("Personalise your survival system"))
        addNote(content, "Approximate details are sufficient. Your profile is encrypted using Android Keystore; it is not uploaded. You may leave any field blank.")
        val location = input("Region, city or approximate ZIP code", profile.region)
        val household = input("Household: number of people, age ranges", profile.household, 2)
        val resources = input("Tools, transport, power sources and stored supplies", profile.resources, 3)
        val care = input("Optional care needs, allergies, mobility or medical dependencies", profile.careNotes, 3)
        listOf(location,household,resources,care).forEach { content.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = px(10) }) }
        content.addView(action("Save encrypted profile") {
            profile = SurvivalProfile(location.text.toString().take(100), household.text.toString().take(300), resources.text.toString().take(700), care.text.toString().take(500))
            try { secure.save(profile); toast("Saved privately on this device.") }
            catch (e: Exception) { toast("Could not save encrypted profile: ${e.message}") }
        })
        addNote(content, "Regional downloads are not available in this early build. Location is only supplied as context to your offline model and is not sent to a server.")
    }
    private fun showStatus() = scrollPage { content ->
        content.addView(section("Offline readiness"))
        addNote(content, "Inference engine: ${if (engine != null) "initialised" else "starting or unavailable"}")
        addNote(content, "AI model: ${model?.name ?: "Not loaded"}")
        addNote(content, "Reference index: ${knowledge.count()} documents stored locally")
        addNote(content, "Local profile: ${if (profile.region.isBlank()) "No region selected" else profile.region}")
        addNote(content, "Regional ecology package: not installed")
        addNote(content, "Offline map package: not installed")
        addNote(content, "Verified medical protocols: not installed")
        addNote(content, "Offline voice engine: not installed")
        addNote(content, "Testing requirements: launch in airplane mode; import a GGUF; generate a response; search a document; restart and verify saved profile.")
        addNote(content, "App version: development build 0.1. This is not an emergency-certified product.")
    }
    private fun updateIndicator() {
        if (!::indicator.isInitialized) return
        indicator.text = when {
            stopping -> "Offline - Stopping..."
            isGenerating && isThinking -> "Offline - Thinking..."
            isGenerating -> "Offline • Generating…"
            isModelLoading -> "Offline • Loading model…"
            model != null -> "Offline • ${model?.name} loaded"
            engine == null -> "Offline • Engine starting…"
            else -> "Offline • Choose a local GGUF model"
        }
    }
    private fun updateBottomNav() {
        val nav = bottomNav ?: return
        for (i in 0 until nav.childCount) {
            val button = nav.getChildAt(i) as? Button ?: continue
            val isSelected = button.text == currentPage
            button.setTextColor(if (isSelected) accent else textSecondary)
            button.setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
        }
    }
    private fun persistTranscript() {
        val entries = JSONArray()
        for ((role, body) in transcript.takeLast(30)) {
            entries.put(JSONObject().put("role", role).put("body", body.take(6000)))
        }
        try { secure.saveHistory(entries.toString()) } catch (_: Exception) { /* Keep chat in memory if storage encryption fails. */ }
    }
    private fun restoreTranscript() {
        try {
            val array = JSONArray(secure.readHistory())
            for (i in 0 until array.length()) {
                val line = array.getJSONObject(i)
                transcript.add(line.optString("role") to line.optString("body"))
            }
        } catch (_: Exception) { transcript.clear() }
    }
    override fun onDestroy() {
        generation?.cancel()
        uiHandler.removeCallbacksAndMessages(null)
        knowledge.close()
        super.onDestroy()
    }

    private fun markdownToSpanned(source: String): Spanned {
        val sb = SpannableStringBuilder()
        val lines = source.split("\n")
        var inCodeBlock = false
        val codeLines = mutableListOf<String>()

        for ((index, line) in lines.withIndex()) {
            val trimmed = line.trimStart()

            if (trimmed.startsWith("```")) {
                if (inCodeBlock) {
                    val codeText = codeLines.joinToString("\n")
                    if (codeText.isNotEmpty()) {
                        val start = sb.length
                        sb.append(codeText)
                        sb.setSpan(TypefaceSpan("monospace"), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        sb.setSpan(BackgroundColorSpan(background), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    }
                    codeLines.clear()
                    inCodeBlock = false
                } else {
                    inCodeBlock = true
                }
                continue
            }

            if (inCodeBlock) {
                codeLines.add(line)
                continue
            }

            val lineStart = sb.length

            when {
                trimmed.startsWith("### ") -> {
                    sb.append(trimmed.substring(4))
                    sb.setSpan(RelativeSizeSpan(1.15f), lineStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(StyleSpan(Typeface.BOLD), lineStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("## ") -> {
                    sb.append(trimmed.substring(3))
                    sb.setSpan(RelativeSizeSpan(1.3f), lineStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(StyleSpan(Typeface.BOLD), lineStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("# ") -> {
                    sb.append(trimmed.substring(2))
                    sb.setSpan(RelativeSizeSpan(1.5f), lineStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(StyleSpan(Typeface.BOLD), lineStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                    sb.append("  • ").append(trimmed.substring(2))
                }
                else -> {
                    sb.append(line)
                }
            }

            applyInlineMarkdown(sb, lineStart, sb.length)

            if (index < lines.size - 1) {
                sb.append("\n")
            }
        }

        if (inCodeBlock && codeLines.isNotEmpty()) {
            val codeText = codeLines.joinToString("\n")
            val start = sb.length
            sb.append(codeText)
            sb.setSpan(TypefaceSpan("monospace"), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(BackgroundColorSpan(background), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }

        return sb
    }

    private fun applyInlineMarkdown(sb: SpannableStringBuilder, start: Int, end: Int) {
        val patterns = listOf(
            Regex("`([^`]+)`") to TypefaceSpan("monospace"),
            Regex("\\*\\*([^*]+)\\*\\*") to StyleSpan(Typeface.BOLD),
            Regex("(?<!\\*)\\*(?!\\*)([^*]+)\\*(?!\\*)") to StyleSpan(Typeface.ITALIC)
        )
        for ((pattern, style) in patterns) {
            val matches = pattern.findAll(sb.substring(start)).toList().asReversed()
            for (match in matches) {
                val left = start + match.range.first
                val right = start + match.range.last + 1
                val content = match.groupValues[1]
                sb.replace(left, right, content)
                val span = if (style is StyleSpan) StyleSpan(style.style) else TypefaceSpan("monospace")
                sb.setSpan(span, left, left + content.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
    }
}
