# Licences and redistribution

The project overlays the Android example distributed with llama.cpp.
Before distribution, inspect the exact upstream licence at the pinned commit
and preserve all required notices for llama.cpp, ggml, Android dependencies and
model weights. The application does not ship any commercial/community model
weights. Every published model entry needs a documented licence review, source,
checksum, format compatibility test and distribution review.

App source code in this prototype is offered without warranty for local evaluation.
It is not a verified emergency or medical device and should not be published as one.
