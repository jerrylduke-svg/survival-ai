#include "generation_budget.h"
#include <cassert>

int main() {
    GenerationBudget budget;
    budget.reset(1024);
    int position = 8180;
    for (int token = 0; token < 1024; ++token) {
        assert(!budget.reached());
        if (position >= 8188) position /= 2; // Same shift the runtime can perform.
        ++position;
        budget.record();
    }
    assert(budget.reached());
    assert(budget.generated() == 1024);
    budget.reset(3); // Recovery uses a fresh budget after cancellation/truncation.
    assert(budget.generated() == 0 && !budget.reached());
    for (int i = 0; i < 3; ++i) budget.record();
    assert(budget.reached());
    budget.reset(0);
    assert(budget.reached());
    budget.reset(-1);
    assert(budget.reached());
    assert(prompt_fits(8188, 8192, 4));
    assert(!prompt_fits(8189, 8192, 4));
    assert(!prompt_fits(-1, 8192, 4));
}
